"""
Package initialization for the recommendation system source modules.
"""

__version__ = "1.0.0"
__author__ = "Prabhatee Bora"
